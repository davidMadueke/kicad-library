from .impart_action import ActionImpartPlugin

ActionImpartPlugin().register()
